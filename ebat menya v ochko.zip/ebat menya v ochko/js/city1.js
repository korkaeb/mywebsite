document.addEventListener('DOMContentLoaded', function() {
    const sliderTrack = document.querySelector('.slider-track');
    const prevButton = document.querySelector('.slider-prev');
    const nextButton = document.querySelector('.slider-next');
    let currentPosition = 0;

    function initSlider() {
        const cards = document.querySelectorAll('.experience-card');
        if (!cards.length) return;

        const cardWidth = cards[0].offsetWidth;
        const gap = 25;
        const containerWidth = document.querySelector('.experience-slider').offsetWidth;
        const visibleCards = Math.floor(containerWidth / (cardWidth + gap));
        const maxScroll = (cards.length - visibleCards) * (cardWidth + gap);

        // Удаляем старые слушатели событий
        prevButton.removeEventListener('click', slidePrev);
        nextButton.removeEventListener('click', slideNext);

        // Функции для перемещения слайдера
        function slidePrev() {
            if (currentPosition < 0) {
                currentPosition += (cardWidth + gap);
                if (currentPosition > 0) currentPosition = 0;
                sliderTrack.style.transform = `translateX(${currentPosition}px)`;
                updateButtonStates();
            }
        }

        function slideNext() {
            const newPosition = currentPosition - (cardWidth + gap);
            if (Math.abs(newPosition) <= maxScroll) {
                currentPosition = newPosition;
                sliderTrack.style.transform = `translateX(${currentPosition}px)`;
                updateButtonStates();
            }
        }

        // Функция обновления состояния кнопок
        function updateButtonStates() {
            prevButton.disabled = currentPosition >= 0;
            nextButton.disabled = Math.abs(currentPosition) >= maxScroll;
            
            // Обновляем визуальное состояние кнопок
            prevButton.style.opacity = prevButton.disabled ? '0.5' : '1';
            nextButton.style.opacity = nextButton.disabled ? '0.5' : '1';
        }

        // Добавляем новые слушатели событий
        prevButton.addEventListener('click', slidePrev);
        nextButton.addEventListener('click', slideNext);

        // Инициализируем состояние кнопок
        updateButtonStates();
    }

    // Инициализация слайдера
    initSlider();

    // Обновление слайдера при изменении размера окна
    let resizeTimer;
    window.addEventListener('resize', function() {
        clearTimeout(resizeTimer);
        resizeTimer = setTimeout(initSlider, 250);
    });

    // Модальное окно для списка включено/не включено
    const includedModal = document.querySelector('.included-modal');
    const includedModalTrigger = document.querySelector('.full-list-link');
    const includedModalClose = document.querySelector('.included-modal-close');

    if (includedModal && includedModalTrigger && includedModalClose) {
        includedModalTrigger.addEventListener('click', function(e) {
            e.preventDefault();
            includedModal.style.display = 'flex';
            document.body.style.overflow = 'hidden';
        });

        includedModalClose.addEventListener('click', function() {
            includedModal.style.display = 'none';
            document.body.style.overflow = '';
        });

        includedModal.addEventListener('click', function(e) {
            if (e.target === includedModal) {
                includedModal.style.display = 'none';
                document.body.style.overflow = '';
            }
        });
    }

    // Модальное окно для форм обратной связи
    const tourModal = document.querySelector('.tour-form-modal');
    const tourModalTriggers = document.querySelectorAll('.learn-more-btn, .request-btn');
    const tourModalClose = document.querySelector('.tour-modal-close');

    if (tourModal && tourModalTriggers && tourModalClose) {
        tourModalTriggers.forEach(trigger => {
            trigger.addEventListener('click', function(e) {
                e.preventDefault();
                tourModal.style.display = 'flex';
                document.body.style.overflow = 'hidden';
                
                // Меняем заголовок в зависимости от кнопки
                const modalTitle = tourModal.querySelector('.tour-modal-title');
                if (modalTitle) {
                    if (this.classList.contains('learn-more-btn')) {
                        modalTitle.textContent = 'Узнать больше о туре';
                    } else if (this.classList.contains('request-btn')) {
                        modalTitle.textContent = 'Оставить заявку на индивидуальный тур';
                    }
                }
            });
        });

        tourModalClose.addEventListener('click', function() {
            tourModal.style.display = 'none';
            document.body.style.overflow = '';
        });

        tourModal.addEventListener('click', function(e) {
            if (e.target === tourModal) {
                tourModal.style.display = 'none';
                document.body.style.overflow = '';
            }
        });
    }
}); 