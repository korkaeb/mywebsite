document.addEventListener('DOMContentLoaded', function() {
    // Слайдер для секции experience
    const sliderTrack = document.querySelector('.slider-track');
    const prevButton = document.querySelector('.slider-prev');
    const nextButton = document.querySelector('.slider-next');
    const cards = document.querySelectorAll('.experience-card');
    
    let currentPosition = 0;
    const cardWidth = cards[0].offsetWidth + 20; // Ширина карточки + отступ
    const maxPosition = -(cards.length * cardWidth - sliderTrack.offsetWidth);

    // Обработчик для кнопки "Предыдущий"
    prevButton.addEventListener('click', () => {
        currentPosition = Math.min(currentPosition + cardWidth, 0);
        updateSliderPosition();
    });

    // Обработчик для кнопки "Следующий"
    nextButton.addEventListener('click', () => {
        currentPosition = Math.max(currentPosition - cardWidth, maxPosition);
        updateSliderPosition();
    });

    // Функция обновления позиции слайдера
    function updateSliderPosition() {
        sliderTrack.style.transform = `translateX(${currentPosition}px)`;
    }

    // Модальные окна и другие интерактивные элементы
    const askQuestionBtn = document.getElementById('ask-question');
    const tourFormModal = document.querySelector('.tour-form-modal');
    const modalClose = document.querySelector('.tour-modal-close');

    if (askQuestionBtn && tourFormModal && modalClose) {
        askQuestionBtn.addEventListener('click', (e) => {
            e.preventDefault();
            tourFormModal.style.display = 'flex';
        });

        modalClose.addEventListener('click', () => {
            tourFormModal.style.display = 'none';
        });

        window.addEventListener('click', (e) => {
            if (e.target === tourFormModal) {
                tourFormModal.style.display = 'none';
            }
        });
    }

    // Обработчик для полного списка включено/не включено
    const fullListLink = document.querySelector('.full-list-link');
    const includedModal = document.querySelector('.included-modal');
    const includedModalClose = document.querySelector('.included-modal-close');

    if (fullListLink && includedModal && includedModalClose) {
        fullListLink.addEventListener('click', (e) => {
            e.preventDefault();
            includedModal.style.display = 'flex';
        });

        includedModalClose.addEventListener('click', () => {
            includedModal.style.display = 'none';
        });

        window.addEventListener('click', (e) => {
            if (e.target === includedModal) {
                includedModal.style.display = 'none';
            }
        });
    }
});
