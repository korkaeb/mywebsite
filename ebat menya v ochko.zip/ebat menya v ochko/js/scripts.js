document.addEventListener('DOMContentLoaded', function() {
    const modal = document.getElementById('modal');
    const openModalButton = document.getElementById('ask-question');
    const closeModalButton = document.querySelector('.close');
    const cards = document.querySelectorAll('.benefit-card');

    openModalButton.addEventListener('click', function(event) {
        event.preventDefault();
        modal.style.display = 'flex';
    });

    closeModalButton.addEventListener('click', function() {
        modal.style.display = 'none';
    });

    window.addEventListener('click', function(event) {
        if (event.target === modal) {
            modal.style.display = 'none';
        }
    });

    const observer = new IntersectionObserver(entries => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
            }
        });
    });

    cards.forEach(card => {
        observer.observe(card);
    });

    // Добавляем код для бесконечного слайдера
    const track = document.querySelector('.collage-track');
    if (track) {
        // Клонируем изображения для бесшовной анимации
        const images = track.querySelectorAll('img');
        images.forEach(img => {
            const clone = img.cloneNode(true);
            track.appendChild(clone);
        });

        // Функция для анимации
        function animate() {
            // Если слайдер достиг половины
            if (track.offsetLeft <= -(track.offsetWidth / 2)) {
                track.style.left = '0px';
            }
            // Двигаем слайдер
            track.style.left = (track.offsetLeft - 1) + 'px';
            requestAnimationFrame(animate);
        }

        // Запускаем анимацию
        track.style.left = '0px';
        animate();
    }

    const sliderTrack = document.querySelector('.slider-track');
    const prevButton = document.querySelector('.slider-prev');
    const nextButton = document.querySelector('.slider-next');
    let currentPosition = 0;

    function updateSlider() {
        const cards = document.querySelectorAll('.experience-card');
        const cardWidth = cards[0].offsetWidth;
        const gap = 25; // Отступ между карточками
        const containerWidth = document.querySelector('.experience-slider').offsetWidth;
        const visibleCards = Math.floor(containerWidth / (cardWidth + gap));
        const maxScroll = (cards.length - visibleCards) * (cardWidth + gap);

        prevButton.addEventListener('click', () => {
            if (currentPosition < 0) {
                currentPosition += (cardWidth + gap);
                if (currentPosition > 0) currentPosition = 0;
                sliderTrack.style.transform = `translateX(${currentPosition}px)`;
            }
        });

        nextButton.addEventListener('click', () => {
            if (Math.abs(currentPosition) < maxScroll) {
                currentPosition -= (cardWidth + gap);
                sliderTrack.style.transform = `translateX(${currentPosition}px)`;
            }
        });
    }

    // Вызываем функцию при загрузке и при изменении размера окна
    updateSlider();
    window.addEventListener('resize', updateSlider);
});
    